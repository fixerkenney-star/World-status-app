# Content and copyright

The sample images and video URLs are only demo references for development.

For a production release of Status World, use:
- original content created by you, or
- content with a license that explicitly permits redistribution in an app, and
- proper attribution where the license requires it.

Do not download, scrape, or redistribute private WhatsApp statuses or other copyrighted material without permission.