# Status World — Android MVP

Status World is an English Android status app MVP for text, image and video status content.

## Included

- Jetpack Compose UI
- Home + Favorites tabs
- Search
- Text/image/video status cards
- Favorites (in-memory MVP)
- Android share sheet
- Banner AdMob integration using Google's TEST ad unit
- Android 16 / API 36 target
- Media3 dependency ready for real video playback
- Coil image loading
- Sample content placeholders

## Important before publishing

1. Replace the sample/demo media with content you own or have a commercial license to distribute.
2. Replace the AdMob application ID and banner ad unit ID with your own IDs. The IDs in this project are Google's test IDs.
3. Add a real privacy policy URL and complete Google Play Data safety declarations.
4. Create a release keystore / use Play App Signing.
5. Build a signed Android App Bundle (`.aab`), not an APK, for the Play release.
6. Test on multiple Android devices.
7. Complete Play Console developer/account verification and any required testing track.
8. After publishing, link the Play listing in AdMob and complete app readiness / app-ads.txt requirements.

## Suggested next engineering step

Move status metadata and media URLs from the hard-coded list into a backend (Firebase Firestore/Storage or another API), add persistent favorites, real video playback, categories, and a lightweight admin workflow for uploading licensed content.