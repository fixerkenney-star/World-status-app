package com.statusworld.app

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import androidx.compose.ui.viewinterop.AndroidView

data class Status(
    val id: String,
    val category: String,
    val text: String,
    val type: String,
    val imageUrl: String? = null,
    val videoUrl: String? = null
)

private val statuses = listOf(
    Status("1","Motivation","Small steps every day become big results.","text"),
    Status("2","Love","Love grows when you choose each other every day.","text"),
    Status("3","Life","Make today so beautiful that tomorrow becomes jealous.","text"),
    Status("4","Good Morning","Good morning. New day, new energy, new possibilities.","image",
        "https://images.unsplash.com/photo-1497250681960-ef046c08a56e?w=900"),
    Status("5","Nature","Breathe in peace. Breathe out pressure.","image",
        "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=900"),
    Status("6","Motivation","Your future self is watching what you do today.","video",
        "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)
        setContent { StatusWorldApp() }
    }
}

@Composable
fun StatusWorldApp() {
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    val favorites = remember { mutableStateListOf<String>() }
    val context = LocalContext.current

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF7B3FF2),
            secondary = Color(0xFFFF6B6B),
            background = Color(0xFFFFF7F2),
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFFFF7F2),
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Home, null) },
                        label = { Text("Home") }
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Favorite, null) },
                        label = { Text("Favorites") }
                    )
                }
            }
        ) { padding ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                Header(query) { query = it }

                val source = if (tab == 0) statuses else statuses.filter { it.id in favorites }
                val filtered = source.filter {
                    query.isBlank() ||
                    it.text.contains(query, true) ||
                    it.category.contains(query, true)
                }

                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Text(
                            if (tab == 0) "Fresh statuses" else "Your favorites",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("Ready to share on WhatsApp, Instagram and more.")
                    }

                    items(filtered, key = { it.id }) { status ->
                        StatusCard(
                            status = status,
                            favorite = status.id in favorites,
                            onFavorite = {
                                if (status.id in favorites) favorites.remove(status.id)
                                else favorites.add(status.id)
                            },
                            onShare = {
                                val shareText = status.text
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, shareText)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share status"))
                            }
                        )
                    }

                    if (filtered.isEmpty()) {
                        item {
                            Text("No statuses found. Try another search.")
                        }
                    }

                    item {
                        BannerAd()
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(query: String, onQueryChange: (String) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF7B3FF2), Color(0xFFFF6B6B))
                )
            )
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Text("Status World", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text("Your daily dose of shareable moments", color = Color.White.copy(alpha = .9f))
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search statuses…") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color.White,
                focusedContainerColor = Color.White,
                unfocusedBorderColor = Color.Transparent,
                focusedBorderColor = Color.Transparent
            ),
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
private fun StatusCard(
    status: Status,
    favorite: Boolean,
    onFavorite: () -> Unit,
    onShare: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column {
            when (status.type) {
                "image" -> {
                    AsyncImage(
                        model = status.imageUrl,
                        contentDescription = status.category,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
                "video" -> {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.VideoLibrary, null, tint = Color.White, modifier = Modifier.size(54.dp))
                        Text("Video status", color = Color.White, modifier = Modifier.padding(top = 76.dp))
                    }
                }
                else -> {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF7B3FF2), Color(0xFF2F80ED))
                                )
                            )
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            status.text,
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AssistChip(
                        onClick = {},
                        label = { Text(status.category) },
                        leadingIcon = {
                            Icon(
                                when(status.type) {
                                    "image" -> Icons.Default.Image
                                    "video" -> Icons.Default.VideoLibrary
                                    else -> Icons.Default.TextFields
                                },
                                null
                            )
                        }
                    )
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = onFavorite) {
                        Icon(
                            if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite"
                        )
                    }
                    IconButton(onClick = onShare) {
                        Icon(Icons.Default.Share, contentDescription = "Share")
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(status.text, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun BannerAd() {
    AndroidView(
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp),
        factory = { context ->
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                // Google's official test banner ad unit ID.
                adUnitId = "ca-app-pub-3940256099942544/6300978111"
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}